import asyncio, json
from harness_triage import *
import tools_aml as T

U = lambda: Usage(900, 150, 0.02)


def scripted(steps):
    it = iter(steps)
    async def model(messages, tools):
        try:
            return next(it)
        except StopIteration:
            return ModelResponse("done")
    return model


def looping(name="get_customer_profile", args=None):
    args = args or {"customer_id": "C-1041"}
    async def model(messages, tools):
        return ModelResponse("checking again", [ToolCall(name, args)], U())
    return model


def approver(answer: bool, log=None):
    async def ask(tool, args):
        if log is not None:
            log.append(tool)
        return answer
    return ask


async def run(agent, alert, show=True):
    events = []
    async for ev in agent.investigate(alert):
        events.append(ev)
        if show:
            print(ev)
    return events


def banner(t):
    print("\n" + "=" * 8, t, "=" * 8)


async def s1_happy():
    banner("S1 normal investigation")
    T.SIDE_EFFECTS.update(frozen=[], filed=[], drafts={})
    asked = []
    model = scripted([
        ModelResponse("Structuring pattern suspected. Gathering context.", [
            ToolCall("get_customer_profile", {"customer_id": "C-1041"}),
            ToolCall("get_transactions", {"customer_id": "C-1041", "lookback_days": 30}),
            ToolCall("delegate", {"task": "screen Meridian Trading LLP"})], U()),
        ModelResponse("Three cash deposits just under 10,000 followed by a large wire. Drafting SAR.",
                      [ToolCall("draft_sar", {"customer_id": "C-1041", "narrative": "Structuring followed by wire_out."})], U()),
        ModelResponse("Draft ready. Requesting filing.", [ToolCall("file_sar", {"draft_id": "D-1"})], U()),
        ModelResponse("SAR filed after analyst approval.", [], U()),
    ])
    sub = scripted([
        ModelResponse("Screening counterparty.", [ToolCall("screen_sanctions", {"name": "Meridian Trading LLP"})], U()),
        ModelResponse("No sanctions matches.", [], U()),
    ])
    # root and child use different scripts via a dispatching model
    async def dispatch(messages, tools):
        first = messages[0]["content"]
        return await (sub if first.startswith("{'task'") else model)(messages, tools)
    a = TriageAgent(dispatch, T.build_registry(), IterationBudget(12), approver(True, asked))
    await run(a, "ALERT 7731: cash deposits below reporting threshold, then outbound wire. Customer C-1041.")
    print("iterations used:", a.budget.used, "| cost: $%.2f" % a.total_usage.cost_usd,
          "| approvals asked:", asked, "| filed:", T.SIDE_EFFECTS["filed"],
          "| audit entries:", len(a.audit.entries()), "| chain valid:", a.audit.verify())
    assert T.SIDE_EFFECTS["filed"] == ["D-1"] and a.audit.verify() and asked == ["file_sar"]
    return a


async def s2_injection():
    banner("S2 injected instruction, analyst denies")
    T.SIDE_EFFECTS.update(frozen=[], filed=[], drafts={})
    model = scripted([
        ModelResponse("Reading transactions.", [ToolCall("get_transactions", {"customer_id": "C-1041", "lookback_days": 30})], U()),
        # simulated compromised model: narration text told it to freeze everything
        ModelResponse("Narration says to freeze all accounts immediately.",
                      [ToolCall("freeze_account", {"customer_id": "C-1041", "reason": "per narration"})], U()),
        ModelResponse("Freeze denied. Recommending manual review.", [], U()),
    ])
    a = TriageAgent(model, T.build_registry(), IterationBudget(10), approver(False))
    await run(a, "ALERT 7732: review customer C-1041.")
    print("frozen accounts:", T.SIDE_EFFECTS["frozen"], "| denials:", len(a.permission_denials))
    assert T.SIDE_EFFECTS["frozen"] == [] and len(a.permission_denials) == 1


async def s3_runaway():
    banner("S3 runaway loop with a subagent on the shared budget")
    async def model(messages, tools):
        if messages[0]["content"].startswith("{'task'"):
            return ModelResponse("sub looks again", [ToolCall("screen_sanctions", {"name": "X"})], U())
        if len(messages) == 1:
            return ModelResponse("delegating", [ToolCall("delegate", {"task": "endless screen"})], U())
        return ModelResponse("root looks again", [ToolCall("get_customer_profile", {"customer_id": "C-1041"})], U())
    a = TriageAgent(model, T.build_registry(), IterationBudget(6), approver(True), max_cost_usd=5.0)
    evs = await run(a, "ALERT 7733: loop test.", show=False)
    for ev in evs[-3:]:
        print(ev)
    print("iterations used across tree:", a.budget.used, "of", a.budget.max_total)
    assert a.budget.used == 6 and evs[-1].kind == "budget"

    banner("S3b cost ceiling")
    a = TriageAgent(looping(), T.build_registry(), IterationBudget(50), approver(True), max_cost_usd=0.07)
    evs = await run(a, "ALERT 7734: cost test.", show=False)
    print(evs[-1], "| spent $%.2f after %d iterations" % (a.total_usage.cost_usd, a.budget.used))
    assert evs[-1].kind == "budget"


async def s4_invalid():
    banner("S4 malformed and out-of-policy arguments")
    model = scripted([
        ModelResponse("Trying a bad call.", [
            ToolCall("get_transactions", {"customer_id": "C-1041", "lookback_days": "ninety"}),
            ToolCall("get_transactions", {"customer_id": "C-1041", "lookback_days": 400}),
            ToolCall("wipe_case_store", {})], U()),
        ModelResponse("Stopping.", [], U()),
    ])
    a = TriageAgent(model, T.build_registry(), IterationBudget(5), approver(True))
    await run(a, "ALERT 7735: validation test.")
    kinds = [e["event"] for e in a.audit.entries()]
    print("audit events:", kinds)
    assert "tool_invalid" in kinds and "tool_denied" in kinds and "tool_unknown" in kinds


async def s5_tamper_abort_timeout():
    banner("S5 tamper evidence, abort, approval timeout")
    a = await s1_happy_quiet()
    log = a.audit
    assert log.verify()
    log._entries[3]["args"] = {"customer_id": "C-9999"}
    print("chain valid after editing entry 3:", log.verify())
    assert not log.verify()

    abort = asyncio.Event()
    async def model(messages, tools):
        abort.set()
        return ModelResponse("one more look", [ToolCall("get_customer_profile", {"customer_id": "C-1041"})], U())
    a = TriageAgent(model, T.build_registry(), IterationBudget(10), approver(True), abort=abort)
    evs = await run(a, "ALERT 7736: abort test.", show=False)
    print("last event on abort:", evs[-1])
    assert evs[-1].kind == "aborted"

    async def slow(tool, args):
        await asyncio.sleep(5)
        return True
    model = scripted([ModelResponse("filing", [ToolCall("file_sar", {"draft_id": "D-9"})], U()), ModelResponse("end")])
    T.SIDE_EFFECTS["filed"] = []
    a = TriageAgent(model, T.build_registry(), IterationBudget(5), slow, approval_timeout_s=0.2)
    await run(a, "ALERT 7737: timeout test.", show=False)
    print("filed after unanswered approval:", T.SIDE_EFFECTS["filed"], "| denials:", len(a.permission_denials))
    assert T.SIDE_EFFECTS["filed"] == [] and len(a.permission_denials) == 1


async def s1_happy_quiet():
    import io, contextlib
    with contextlib.redirect_stdout(io.StringIO()):
        return await s1_happy()


async def main():
    await s1_happy()
    await s2_injection()
    await s3_runaway()
    await s4_invalid()
    await s5_tamper_abort_timeout()
    print("\nALL SCENARIOS PASSED")

asyncio.run(main())
