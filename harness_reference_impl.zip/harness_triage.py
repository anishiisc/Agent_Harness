"""
harness_triage.py

A reference harness for an anti-money-laundering (AML) alert triage agent.

The design follows the harness paradigm of Huang and Huang (Chapter 1):
  * one object owns all mutable session state (messages, usage, denials, audit)
  * the public entry point is an async generator that streams events
  * every action is a typed Tool with declared behaviour
  * a thread-safe IterationBudget bounds work across the whole agent tree
  * destructive tools pass through an approval gate that fails closed
  * every decision is written to an append-only, hash-chained audit log

The model is a plain async callable, so the harness can be tested with a
scripted model and no network access.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, AsyncGenerator, Awaitable, Callable, Optional


# --------------------------------------------------------------------------
# Budget
# --------------------------------------------------------------------------
class IterationBudget:
    """Thread-safe counter shared by a parent agent and all its subagents."""

    def __init__(self, max_total: int):
        self.max_total = max_total
        self._used = 0
        self._lock = threading.Lock()

    def consume(self) -> bool:
        with self._lock:
            if self._used >= self.max_total:
                return False
            self._used += 1
            return True

    def refund(self) -> None:
        with self._lock:
            if self._used > 0:
                self._used -= 1

    @property
    def used(self) -> int:
        with self._lock:
            return self._used

    @property
    def remaining(self) -> int:
        with self._lock:
            return max(0, self.max_total - self._used)


@dataclass
class Usage:
    """Cumulative token and cost accounting, rolled up from subagents."""
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0

    def add(self, other: "Usage") -> None:
        self.input_tokens += other.input_tokens
        self.output_tokens += other.output_tokens
        self.cost_usd += other.cost_usd


# --------------------------------------------------------------------------
# Tool contract and registry
# --------------------------------------------------------------------------
class Decision(str, Enum):
    ALLOW = "allow"
    ASK = "ask"
    DENY = "deny"


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    schema: dict                      # field name -> python type
    handler: Callable[[dict], str]
    read_only: bool = False
    destructive: bool = False
    concurrency_safe: bool = False
    max_result_chars: int = 400
    check_fn: Callable[[], bool] = lambda: True          # availability guard
    check_permissions: Optional[Callable[[dict], Optional[Decision]]] = None


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, ToolSpec] = {}

    def register(self, spec: ToolSpec) -> None:
        if spec.name in self._tools:
            raise ValueError(f"duplicate tool: {spec.name}")
        self._tools[spec.name] = spec

    def get(self, name: str) -> Optional[ToolSpec]:
        spec = self._tools.get(name)
        return spec if spec and spec.check_fn() else None

    def names(self) -> list[str]:
        return [n for n, s in self._tools.items() if s.check_fn()]

    def read_only_view(self) -> "ToolRegistry":
        """A registry containing only read-only tools, for subagents."""
        view = ToolRegistry()
        for spec in self._tools.values():
            if spec.read_only:
                view.register(spec)
        return view


def validate_args(spec: ToolSpec, args: Any) -> list[str]:
    """Reject malformed input before it can reach tool code."""
    if not isinstance(args, dict):
        return ["arguments must be an object"]
    errors = []
    for key, typ in spec.schema.items():
        if key not in args:
            errors.append(f"missing field: {key}")
        elif isinstance(args[key], bool) or not isinstance(args[key], typ):
            errors.append(f"field {key} must be {typ.__name__}")
    for key in args:
        if key not in spec.schema:
            errors.append(f"unexpected field: {key}")
    return errors


# --------------------------------------------------------------------------
# Audit log
# --------------------------------------------------------------------------
class AuditLog:
    """Append-only log. Each entry commits to the one before it."""

    GENESIS = "0" * 64

    def __init__(self) -> None:
        self._entries: list[dict] = []
        self._lock = threading.Lock()

    @staticmethod
    def _digest(prev: str, body: dict) -> str:
        blob = json.dumps(body, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256((prev + blob).encode()).hexdigest()

    def append(self, event: str, **data: Any) -> None:
        with self._lock:
            prev = self._entries[-1]["hash"] if self._entries else self.GENESIS
            body = {
                "seq": len(self._entries),
                "ts": datetime.now(timezone.utc).isoformat(),
                "event": event,
                **data,
            }
            self._entries.append({**body, "prev": prev,
                                  "hash": self._digest(prev, body)})

    def entries(self) -> list[dict]:
        with self._lock:
            return [dict(e) for e in self._entries]

    def verify(self) -> bool:
        prev = self.GENESIS
        for e in self._entries:
            body = {k: v for k, v in e.items() if k not in ("prev", "hash")}
            if e["prev"] != prev or e["hash"] != self._digest(prev, body):
                return False
            prev = e["hash"]
        return True


# --------------------------------------------------------------------------
# Model interface
# --------------------------------------------------------------------------
@dataclass
class ToolCall:
    name: str
    args: Any


@dataclass
class ModelResponse:
    text: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    usage: Usage = field(default_factory=Usage)


ModelFn = Callable[[list, list], Awaitable[ModelResponse]]
Approver = Callable[[str, dict], Awaitable[bool]]


@dataclass
class Event:
    kind: str
    detail: str = ""
    agent: str = "root"

    def __str__(self) -> str:
        return f"[{self.kind.upper():<9}] ({self.agent}) {self.detail}"


# --------------------------------------------------------------------------
# The harness
# --------------------------------------------------------------------------
class TriageAgent:
    def __init__(
        self,
        model: ModelFn,
        registry: ToolRegistry,
        budget: IterationBudget,
        approver: Approver,
        audit: Optional[AuditLog] = None,
        max_cost_usd: float = 0.50,
        approval_timeout_s: float = 30.0,
        abort: Optional[asyncio.Event] = None,
        name: str = "root",
        usage: Optional[Usage] = None,
        can_delegate: bool = True,
    ) -> None:
        self.model = model
        self.registry = registry
        self.budget = budget                  # shared with subagents
        self.approver = approver
        self.audit = audit if audit is not None else AuditLog()
        self.max_cost_usd = max_cost_usd
        self.approval_timeout_s = approval_timeout_s
        self.abort = abort or asyncio.Event()
        self.name = name
        self.messages: list[dict] = []                    # append-only memory
        self.permission_denials: list[dict] = []          # blocked actions
        self.total_usage = usage if usage is not None else Usage()
        self.final_text = ""
        self.can_delegate = can_delegate

    # -- policy ------------------------------------------------------------
    def _decide(self, spec: ToolSpec, args: dict) -> Decision:
        if spec.check_permissions is not None:
            verdict = spec.check_permissions(args)
            if verdict is not None:
                return verdict
        if spec.destructive:
            return Decision.ASK
        return Decision.ALLOW

    async def _ask_analyst(self, tool: str, args: dict) -> bool:
        try:
            return bool(await asyncio.wait_for(
                self.approver(tool, args), self.approval_timeout_s))
        except asyncio.TimeoutError:
            return False                      # fail closed

    # -- single tool call --------------------------------------------------
    async def _run_tool(self, call: ToolCall) -> tuple[str, str]:
        """Returns (result_text, outcome) where outcome is one of
        ok, error, invalid, denied, unknown."""
        spec = self.registry.get(call.name)
        if spec is None:
            self.audit.append("tool_unknown", agent=self.name, tool=call.name)
            return json.dumps({"error": f"unknown tool {call.name}"}), "unknown"

        problems = validate_args(spec, call.args)
        if problems:
            self.audit.append("tool_invalid", agent=self.name,
                              tool=call.name, problems=problems)
            return json.dumps({"error": "invalid arguments",
                               "problems": problems}), "invalid"

        decision = self._decide(spec, call.args)
        approved = decision is Decision.ALLOW
        if decision is Decision.ASK:
            approved = await self._ask_analyst(call.name, call.args)
        if not approved:
            record = {"tool": call.name, "args": call.args,
                      "decision": decision.value}
            self.permission_denials.append(record)
            self.audit.append("tool_denied", agent=self.name, **record)
            return json.dumps({"error": f"{call.name} denied"}), "denied"

        try:
            raw = await asyncio.to_thread(spec.handler, call.args)
            outcome = "ok"
        except Exception as exc:                          # tool bug or outage
            raw, outcome = json.dumps({"error": str(exc)}), "error"

        if len(raw) > spec.max_result_chars:
            raw = raw[: spec.max_result_chars] + \
                f"...[truncated {len(raw) - spec.max_result_chars} chars]"
        self.audit.append("tool_call", agent=self.name, tool=call.name,
                          args=call.args, decision=decision.value,
                          outcome=outcome, result_preview=raw[:120])
        return raw, outcome

    # -- subagent ----------------------------------------------------------
    async def _delegate(self, task: str) -> AsyncGenerator[Event, None]:
        child = TriageAgent(
            model=self.model,
            registry=self.registry.read_only_view(),   # least privilege
            budget=self.budget,                         # same counter
            approver=self.approver,
            audit=self.audit,                           # same trail
            max_cost_usd=self.max_cost_usd,
            abort=self.abort,
            name=f"{self.name}/sub",
            usage=self.total_usage,                     # costs roll up
            can_delegate=False,                         # no recursion
        )
        self.audit.append("delegate", agent=self.name, task=task)
        async for event in child.investigate(task):
            yield event
        self.messages.append({"role": "tool", "name": "delegate",
                              "content": child.final_text, "untrusted": True})

    # -- main loop -----------------------------------------------------------
    async def investigate(self, alert: str) -> AsyncGenerator[Event, None]:
        self.messages.append({"role": "user", "content": alert})
        self.audit.append("start", agent=self.name, alert=alert[:120])

        while True:
            if self.abort.is_set():
                self.audit.append("aborted", agent=self.name)
                yield Event("aborted", "analyst cancelled the run", self.name)
                return
            if not self.budget.consume():
                self.audit.append("budget_stop", agent=self.name,
                                  reason="iterations")
                yield Event("budget", f"iteration cap of "
                            f"{self.budget.max_total} reached", self.name)
                return
            if self.total_usage.cost_usd >= self.max_cost_usd:
                self.audit.append("budget_stop", agent=self.name,
                                  reason="cost")
                yield Event("budget", f"cost ceiling of "
                            f"${self.max_cost_usd:.2f} reached", self.name)
                return

            response = await self.model(self.messages, self.registry.names())
            self.total_usage.add(response.usage)
            self.messages.append({"role": "assistant", "content": response.text,
                                  "tool_calls": [c.name for c in
                                                 response.tool_calls]})
            if response.text:
                yield Event("analysis", response.text, self.name)

            if not response.tool_calls:
                self.final_text = response.text
                self.audit.append("complete", agent=self.name)
                yield Event("complete", "investigation finished", self.name)
                return

            # Read-only, concurrency-safe calls run together; the rest in order.
            batch: list[ToolCall] = []
            for call in response.tool_calls:
                spec = self.registry.get(call.name)
                safe = bool(spec and spec.read_only and spec.concurrency_safe)
                if safe:
                    batch.append(call)
                    continue
                for ev in await self._flush(batch):
                    yield ev
                batch = []
                if call.name == "delegate" and self.can_delegate:
                    async for ev in self._delegate(str(call.args)):
                        yield ev
                    continue
                if self.abort.is_set():
                    break
                result, outcome = await self._run_tool(call)
                self.messages.append({"role": "tool", "name": call.name,
                                      "content": result, "untrusted": True})
                yield Event("tool" if outcome == "ok" else outcome,
                            f"{call.name} -> {result[:90]}", self.name)
            for ev in await self._flush(batch):
                yield ev

    async def _flush(self, batch: list[ToolCall]) -> list[Event]:
        if not batch:
            return []
        results = await asyncio.gather(*(self._run_tool(c) for c in batch))
        events = []
        for call, (result, outcome) in zip(batch, results):
            self.messages.append({"role": "tool", "name": call.name,
                                  "content": result, "untrusted": True})
            events.append(Event("tool" if outcome == "ok" else outcome,
                                f"{call.name} -> {result[:90]}", self.name))
        return events
