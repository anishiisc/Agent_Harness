"""Domain tools for the AML triage agent. All data is synthetic."""
import json
from harness_triage import Decision, ToolRegistry, ToolSpec

CUSTOMERS = {
    "C-1041": {"name": "Meridian Trading LLP", "segment": "SME", "risk": "medium",
               "onboarded": "2021-03-14", "declared_activity": "textile exports"},
}
TRANSACTIONS = {
    "C-1041": [
        {"id": "T1", "amount": 9400, "type": "cash_deposit", "day": "2026-11-02"},
        {"id": "T2", "amount": 9600, "type": "cash_deposit", "day": "2026-11-03"},
        {"id": "T3", "amount": 9500, "type": "cash_deposit", "day": "2026-11-04"},
        {"id": "T4", "amount": 28000, "type": "wire_out", "day": "2026-11-05",
         "narration": "invoice 88"},
    ],
}
SIDE_EFFECTS = {"frozen": [], "filed": [], "drafts": {}}


def _profile(a):
    return json.dumps(CUSTOMERS.get(a["customer_id"], {"error": "not found"}))


def _transactions(a):
    return json.dumps(TRANSACTIONS.get(a["customer_id"], []))


def _screen(a):
    return json.dumps({"name": a["name"], "matches": 0, "lists": ["UN", "OFAC", "EU"]})


def _draft(a):
    did = f"D-{len(SIDE_EFFECTS['drafts']) + 1}"
    SIDE_EFFECTS["drafts"][did] = a["narrative"]
    return json.dumps({"draft_id": did})


def _freeze(a):
    SIDE_EFFECTS["frozen"].append(a["customer_id"])
    return json.dumps({"frozen": a["customer_id"]})


def _file(a):
    SIDE_EFFECTS["filed"].append(a["draft_id"])
    return json.dumps({"filed": a["draft_id"]})


def _lookback_policy(a):
    days = a.get("lookback_days")
    if isinstance(days, int) and days > 180:
        return Decision.DENY          # data-minimisation rule
    return None


def build_registry() -> ToolRegistry:
    r = ToolRegistry()
    r.register(ToolSpec("get_customer_profile", "KYC profile",
                        {"customer_id": str}, _profile,
                        read_only=True, concurrency_safe=True))
    r.register(ToolSpec("get_transactions", "Transactions in a window",
                        {"customer_id": str, "lookback_days": int}, _transactions,
                        read_only=True, concurrency_safe=True,
                        check_permissions=_lookback_policy))
    r.register(ToolSpec("screen_sanctions", "Sanctions list screening",
                        {"name": str}, _screen,
                        read_only=True, concurrency_safe=True))
    r.register(ToolSpec("draft_sar", "Write a SAR draft to the case store",
                        {"customer_id": str, "narrative": str}, _draft))
    r.register(ToolSpec("freeze_account", "Freeze an account",
                        {"customer_id": str, "reason": str}, _freeze,
                        destructive=True))
    r.register(ToolSpec("file_sar", "File a SAR with the regulator",
                        {"draft_id": str}, _file, destructive=True))
    return r
